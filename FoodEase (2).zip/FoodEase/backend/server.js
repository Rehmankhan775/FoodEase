const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
const authRoutes       = require("./routes/authRoutes");
const restaurantRoutes = require("./routes/restaurantRoutes");
const menuRoutes       = require("./routes/menuRoutes");
const cartRoutes       = require("./routes/cartRoutes");
const orderRoutes      = require("./routes/orderRoutes");

app.use("/api/auth",        authRoutes);
app.use("/api/restaurants", restaurantRoutes);
app.use("/api/menus",       menuRoutes);
app.use("/api/cart",        cartRoutes);
app.use("/api/orders",      orderRoutes);

app.get("/", (req, res) => {
    res.send("FoodEase Backend Running ✔️");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});