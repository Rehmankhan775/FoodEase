const express = require("express");
const router = express.Router();

const restaurantController = require("../controllers/restaurantController");

router.post("/add", restaurantController.addRestaurant);
router.get("/", restaurantController.getRestaurants);
router.delete("/:id", restaurantController.deleteRestaurant);

module.exports = router;