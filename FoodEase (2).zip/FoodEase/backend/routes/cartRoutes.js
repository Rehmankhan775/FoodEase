const express = require("express");
const router = express.Router();
const db = require("../config/db");

// ADD TO CART
router.post("/add", (req, res) => {
    const { user_id, menu_id, quantity } = req.body;

    const checkSql = "SELECT * FROM cart WHERE user_id=? AND menu_id=?";
    db.query(checkSql, [user_id, menu_id], (err, result) => {
        if (err) return res.status(500).json(err);

        if (result.length > 0) {
            const newQty = result[0].quantity + (quantity || 1);
            db.query("UPDATE cart SET quantity=? WHERE user_id=? AND menu_id=?",
                [newQty, user_id, menu_id],
                (err2) => {
                    if (err2) return res.status(500).json(err2);
                    res.json({ message: "Cart updated ✔️" });
                });
        } else {
            db.query("INSERT INTO cart (user_id, menu_id, quantity) VALUES (?,?,?)",
                [user_id, menu_id, quantity || 1],
                (err2) => {
                    if (err2) return res.status(500).json(err2);
                    res.json({ message: "Added to cart ✔️" });
                });
        }
    });
});

// GET CART
router.get("/:user_id", (req, res) => {
    const sql = `
        SELECT c.cart_id, c.quantity,
               m.item_name, m.price,
               (c.quantity * m.price) AS subtotal
        FROM cart c
        JOIN menus m ON c.menu_id = m.menu_id
        WHERE c.user_id = ?`;
    db.query(sql, [req.params.user_id], (err, result) => {
        if (err) return res.status(500).json(err);
        res.json(result);
    });
});

// REMOVE ONE ITEM
router.delete("/:cart_id", (req, res) => {
    db.query("DELETE FROM cart WHERE cart_id=?", [req.params.cart_id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "Removed ✔️" });
    });
});

// CLEAR CART (after order)
router.delete("/clear/:user_id", (req, res) => {
    db.query("DELETE FROM cart WHERE user_id=?", [req.params.user_id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "Cart cleared ✔️" });
    });
});

module.exports = router;