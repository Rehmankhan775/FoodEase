const express = require("express");
const router = express.Router();
const db = require("../config/db");

// PLACE ORDER
router.post("/", (req, res) => {
    const { customer_id, restaurant_id, delivery_address, total_amount, payment_mode } = req.body;

    const sql = `INSERT INTO orders 
        (customer_id, restaurant_id, delivery_address, total_amount, status, payment_mode)
        VALUES (?, ?, ?, ?, 'pending', ?)`;

    db.query(sql, [customer_id, restaurant_id, delivery_address, total_amount, payment_mode || 'cash_on_delivery'],
        (err, result) => {
            if (err) return res.status(500).json(err);
            res.json({ message: "Order placed ✔️", order_id: result.insertId });
        });
});

// GET ALL ORDERS
router.get("/", (req, res) => {
    db.query("SELECT * FROM orders ORDER BY created_at DESC", (err, result) => {
        if (err) return res.status(500).json(err);
        res.json(result);
    });
});

// GET ORDER BY USER
router.get("/user/:user_id", (req, res) => {
    db.query("SELECT * FROM orders WHERE customer_id=? ORDER BY created_at DESC",
        [req.params.user_id], (err, result) => {
            if (err) return res.status(500).json(err);
            res.json(result);
        });
});

module.exports = router;