const express = require("express");
const router = express.Router();

const adminController = require("../controllers/adminController");

// ADMIN DASHBOARD ROUTE
router.get("/dashboard", adminController.dashboard);

module.exports = router;