const express = require("express");
const router = express.Router();
const db = require("../config/db");

// TOTAL SALES
router.get("/sales", (req, res) => {

    db.query("SELECT SUM(total) as totalSales FROM orders", (err, result) => {
        res.json(result[0]);
    });
});

// TOTAL ORDERS
router.get("/orders", (req, res) => {

    db.query("SELECT COUNT(*) as totalOrders FROM orders", (err, result) => {
        res.json(result[0]);
    });
});

module.exports = router;