const express = require("express");
const router = express.Router();

const menuController = require("../controllers/menuController");

router.get("/:id", menuController.getMenu);
router.post("/add", menuController.addMenu);

module.exports = router;