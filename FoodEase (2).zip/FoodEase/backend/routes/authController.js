const db = require("../config/db");

exports.addRestaurant = (req, res) => {
    const { restaurant_name, address } = req.body;

    const sql = `
        INSERT INTO restaurants (owner_id, restaurant_name, address)
        VALUES (?, ?, ?)
    `;

    db.query(sql, [1, restaurant_name, address], (err, result) => {
        if (err) return res.status(500).json(err);

        res.json({
            message: "Added",
            id: result.insertId
        });
    });
};

exports.getRestaurants = (req, res) => {
    db.query("SELECT * FROM restaurants", (err, result) => {
        if (err) return res.status(500).json(err);
        res.json(result);
    });
};

exports.getRestaurant = (req, res) => {
    db.query(
        "SELECT * FROM restaurants WHERE restaurant_id=?",
        [req.params.id],
        (err, result) => {
            if (err) return res.status(500).json(err);
            res.json(result[0] || {});
        }
    );
};

exports.deleteRestaurant = (req, res) => {
    db.query(
        "DELETE FROM restaurants WHERE restaurant_id=?",
        [req.params.id],
        (err) => {
            if (err) return res.status(500).json(err);
            res.json({ message: "Deleted" });
        }
    );
};