const db = require("../config/db");

exports.getMenu = (req, res) => {

    const id = req.params.id;

    db.query("SELECT * FROM menus WHERE restaurant_id = ?", [id], (err, result) => {
        if (err) return res.status(500).json(err);

        res.json(result);
    });
};

exports.addMenu = (req, res) => {

    const { restaurant_id, item_name, price } = req.body;

    db.query(
        "INSERT INTO menus (restaurant_id, item_name, price) VALUES (?, ?, ?)",
        [restaurant_id, item_name, price],
        (err) => {
            if (err) return res.status(500).json(err);

            res.json({ message: "Menu added ✔️" });
        }
    );
};