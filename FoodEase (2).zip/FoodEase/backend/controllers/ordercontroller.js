const db = require("../config/db");

// PLACE ORDER
exports.placeOrder = (req, res) => {

    const { user_id, total } = req.body;

    const sql = `
        INSERT INTO orders (user_id, total, status)
        VALUES (?, ?, 'Pending')
    `;

    db.query(sql, [user_id, total], (err) => {
        if (err) return res.status(500).json(err);

        res.json({ message: "Order placed ✔️" });
    });
};

// GET ORDERS
exports.getOrders = (req, res) => {

    db.query("SELECT * FROM orders", (err, result) => {
        if (err) return res.status(500).json(err);

        res.json(result);
    });
};