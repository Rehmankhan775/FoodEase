exports.dashboard = (req, res) => {

    const users = "SELECT COUNT(*) AS total_users FROM users";
    const orders = "SELECT COUNT(*) AS total_orders FROM orders";
    const revenue = "SELECT SUM(total_amount) AS revenue FROM orders";

    db.query(users, (err, u) => {
        db.query(orders, (err, o) => {
            db.query(revenue, (err, r) => {

                res.json({
                    users: u[0].total_users,
                    orders: o[0].total_orders,
                    revenue: r[0].revenue
                });

            });
        });
    });
};