const db = require("../config/db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
require("dotenv").config();

// REGISTER
exports.register = (req, res) => {

    const { full_name, email, password, phone, role, address } = req.body;

    bcrypt.hash(password, 10, (err, hash) => {
        if (err) return res.status(500).json(err);

        const sql = `
            INSERT INTO users (full_name, email, password, phone, role, address)
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        db.query(sql,
            [full_name, email, hash, phone, role, address],
            (err, result) => {
                if (err) return res.status(500).json(err);

                res.json({ message: "User registered successfully ✔️" });
            }
        );
    });
};

// LOGIN
exports.login = (req, res) => {

    const { email, password } = req.body;

    const sql = "SELECT * FROM users WHERE email = ?";

    db.query(sql, [email], (err, results) => {

        if (err) return res.status(500).json(err);

        if (results.length === 0) {
            return res.status(401).json({ message: "User not found" });
        }

        const user = results[0];

        bcrypt.compare(password, user.password, (err, match) => {

            if (!match) {
                return res.status(401).json({ message: "Invalid password" });
            }

            const token = jwt.sign(
                { id: user.user_id, role: user.role },
                process.env.JWT_SECRET,
                { expiresIn: "1d" }
            );

            res.json({
                message: "Login successful ✔️",
                token,
                user
            });
        });
    });
};