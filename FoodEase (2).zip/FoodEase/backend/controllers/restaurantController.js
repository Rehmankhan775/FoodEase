const db = require("../config/db");

exports.addRestaurant = (req, res) => {

    const { restaurant_name, address } = req.body;

    db.query(
        "INSERT INTO restaurants (restaurant_name, address) VALUES (?, ?)",
        [restaurant_name, address],
        (err, result) => {
            if (err) return res.status(500).json(err);

            res.json({ message: "Restaurant added ✔️" });
        }
    );
};

exports.getRestaurants = (req, res) => {

    db.query("SELECT * FROM restaurants", (err, result) => {
        if (err) return res.status(500).json(err);

        res.json(result);
    });
};

exports.deleteRestaurant = (req, res) => {

    const id = req.params.id;

    db.query("DELETE FROM restaurants WHERE restaurant_id = ?", [id], (err) => {
        if (err) return res.status(500).json(err);

        res.json({ message: "Deleted ✔️" });
    });
};