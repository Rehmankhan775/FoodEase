-- =========================
-- DATABASE CREATE
-- =========================
CREATE DATABASE IF NOT EXISTS foodease;
USE foodease;

-- =========================
-- USERS TABLE
-- =========================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    role ENUM('admin','customer','restaurant_owner','delivery_staff') NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- CATEGORIES TABLE
-- =========================
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL
);

-- =========================
-- RESTAURANTS TABLE
-- =========================
CREATE TABLE restaurants (
    restaurant_id INT AUTO_INCREMENT PRIMARY KEY,
    owner_id INT NOT NULL,
    restaurant_name VARCHAR(100) NOT NULL,
    description TEXT,
    address TEXT,
    contact_number VARCHAR(20),
    cuisine_type VARCHAR(50),
    opening_time TIME,
    closing_time TIME,
    status ENUM('Active','Inactive') DEFAULT 'Active',
    FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- =========================
-- MENUS TABLE
-- =========================
CREATE TABLE menus (
    menu_id INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT,
    category_id INT,
    food_name VARCHAR(100),
    description TEXT,
    price DECIMAL(10,2),
    image VARCHAR(255),
    availability ENUM('Available','Unavailable') DEFAULT 'Available',
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(restaurant_id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL
);

-- =========================
-- ORDERS TABLE
-- =========================
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    restaurant_id INT,
    total_amount DECIMAL(10,2),
    delivery_address TEXT,
    order_status ENUM('Pending','Preparing','Picked','Delivered') DEFAULT 'Pending',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(user_id),
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(restaurant_id)
);

-- =========================
-- ORDER ITEMS TABLE
-- =========================
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    menu_id INT,
    quantity INT,
    price DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (menu_id) REFERENCES menus(menu_id)
);

-- =========================
-- PAYMENTS TABLE
-- =========================
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    payment_method ENUM('Cash On Delivery','Credit Card'),
    payment_status ENUM('Pending','Paid') DEFAULT 'Pending',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- =========================
-- DELIVERY STAFF TABLE
-- =========================
CREATE TABLE delivery_staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    vehicle_type VARCHAR(50),
    license_number VARCHAR(50),
    availability ENUM('Available','Busy') DEFAULT 'Available',
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- =========================
-- DELIVERY ASSIGNMENTS TABLE
-- =========================
CREATE TABLE delivery_assignments (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    staff_id INT,
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivery_status ENUM('Assigned','Picked','Delivered') DEFAULT 'Assigned',
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (staff_id) REFERENCES delivery_staff(staff_id)
);

-- =========================
-- REVIEWS TABLE
-- =========================
CREATE TABLE reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    restaurant_id INT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    review TEXT,
    review_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(user_id),
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(restaurant_id)
);

-- =========================
-- CART TABLE
-- =========================
CREATE TABLE cart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    menu_id INT,
    quantity INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (menu_id) REFERENCES menus(menu_id)
);

-- =========================
-- SAMPLE DATA
-- =========================

INSERT INTO users (full_name, email, password, phone, role, address) VALUES
('Admin', 'admin@foodease.com', '123456', '03000000000', 'admin', 'Lahore'),
('Ali Khan', 'ali@gmail.com', '123456', '03011111111', 'customer', 'Johar Town'),
('Ahmed Raza', 'ahmed@gmail.com', '123456', '03022222222', 'customer', 'Model Town'),
('Sara Noor', 'sara@gmail.com', '123456', '03033333333', 'customer', 'DHA'),
('Pizza Owner', 'pizza@foodease.com', '123456', '03044444444', 'restaurant_owner', 'Gulberg'),
('BBQ Owner', 'bbq@foodease.com', '123456', '03055555555', 'restaurant_owner', 'Iqbal Town'),
('Rider One', 'rider1@foodease.com', '123456', '03066666666', 'delivery_staff', 'Lahore');

INSERT INTO categories (category_name) VALUES
('Fast Food'),
('BBQ'),
('Chinese'),
('Pizza'),
('Drinks');

INSERT INTO restaurants (owner_id, restaurant_name, description, address, contact_number, cuisine_type, opening_time, closing_time)
VALUES
(5,'Pizza House','Best Pizza in town','Gulberg','04211111111','Pizza','10:00','23:00'),
(6,'BBQ Grill','Spicy BBQ','Iqbal Town','04222222222','BBQ','12:00','23:00');

INSERT INTO menus (restaurant_id, category_id, food_name, description, price, image)
VALUES
(1,4,'Chicken Pizza','Cheesy Pizza',1200,'pizza.jpg'),
(1,5,'Cold Drink','Chilled Drink',100,'drink.jpg'),
(2,2,'Chicken Tikka','Spicy BBQ',800,'tikka.jpg');

INSERT INTO delivery_staff (user_id, vehicle_type, license_number)
VALUES
(7,'Bike','LIC-1001');

INSERT INTO orders (customer_id, restaurant_id, total_amount, delivery_address, order_status)
VALUES
(2,1,1300,'Johar Town','Pending');

INSERT INTO order_items (order_id, menu_id, quantity, price)
VALUES
(1,1,1,1200),
(1,2,1,100);

INSERT INTO payments (order_id, payment_method, payment_status)
VALUES
(1,'Cash On Delivery','Pending');

INSERT INTO reviews (customer_id, restaurant_id, rating, review)
VALUES
(2,1,5,'Amazing Pizza!');