let cart = [];

function addToCart(item) {

    cart.push(item);
    renderCart();
}

function renderCart() {

    let html = "";
    let total = 0;

    cart.forEach((item, index) => {

        total += item.price;

        html += `
            <div class="card p-2 mt-2">
                <h6>${item.name}</h6>
                <p>${item.price}</p>

                <button onclick="removeItem(${index})">Remove</button>
            </div>
        `;
    });

    document.getElementById("cart").innerHTML = html;
    document.getElementById("total").innerText = total;
}

function removeItem(index) {
    cart.splice(index, 1);
    renderCart();
}