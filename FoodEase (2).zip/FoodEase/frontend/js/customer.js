const API = "http://localhost:5000/api";

// =========================
// CART STORAGE
// =========================
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// =========================
// LOAD RESTAURANTS
// =========================
function loadRestaurants() {

    fetch(`${API}/restaurants`)
    .then(res => res.json())
    .then(data => {

        let html = "";

        data.forEach(r => {
            html += `
                <div class="col-md-4 mt-3">
                    <div class="card p-3 shadow card-box">

                        <h5>🍽 ${r.restaurant_name}</h5>
                        <p>${r.address}</p>

                        <button class="btn btn-danger btn-sm"
                            onclick="loadMenu(${r.restaurant_id})">
                            View Menu
                        </button>

                        <div id="menu-${r.restaurant_id}"></div>

                    </div>
                </div>
            `;
        });

        document.getElementById("restaurants").innerHTML = html;
    });
}

// =========================
// LOAD MENU (FIXED)
// =========================
function loadMenu(id) {

    fetch(`${API}/menus/${id}`)
    .then(res => res.json())
    .then(data => {

        let html = "<hr><h6>🍔 Menu</h6>";

        data.forEach(m => {

            html += `
                <div class="d-flex justify-content-between align-items-center border p-2 mt-2 rounded">

                    <div>
                        <b>${m.item_name}</b>
                        <div>Rs ${m.price}</div>
                    </div>

                    <button class="btn btn-success btn-sm"
                        onclick="addToCart('${m.item_name}', ${m.price})">
                        Add to Cart
                    </button>

                </div>
            `;
        });

        document.getElementById(`menu-${id}`).innerHTML = html;
    });
}

// =========================
// CART FUNCTION (FIXED)
// =========================
function addToCart(name, price) {

    cart.push({ name, price });

    localStorage.setItem("cart", JSON.stringify(cart));

    alert("Added to Cart ✔️");

    console.log("Cart:", cart);
}

// =========================
// INIT
// =========================
loadRestaurants();