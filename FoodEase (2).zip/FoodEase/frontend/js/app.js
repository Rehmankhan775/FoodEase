const API = "http://localhost:5000/api/restaurants";


// ==========================
// ADD RESTAURANT
// ==========================
function addRestaurant() {

    const name = document.getElementById("name").value;
    const address = document.getElementById("address").value;

    if (!name || !address) {
        alert("Please fill all fields");
        return;
    }

    fetch(API + "/add", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            restaurant_name: name,
            address: address
        })
    })
    .then(res => res.json())
    .then(data => {
        console.log("ADD RESPONSE:", data);

        alert("Restaurant Added ✔️");

        // refresh list after adding
        loadRestaurants();

        // clear inputs
        document.getElementById("name").value = "";
        document.getElementById("address").value = "";
    })
    .catch(err => {
        console.log(err);
        alert("Error adding restaurant");
    });
}


// ==========================
// LOAD RESTAURANTS
// ==========================
function loadRestaurants() {

    fetch(API)
    .then(res => res.json())
    .then(data => {

        let html = "";

        data.forEach(r => {
            html += `
                <div class="col-md-4 mt-2">
                    <div class="card p-3 shadow">
                        <h5>${r.restaurant_name}</h5>
                        <p>${r.address}</p>
                    </div>
                </div>
            `;
        });

        document.getElementById("list").innerHTML = html;
    })
    .catch(err => {
        console.log("LOAD ERROR:", err);
    });
}


// ==========================
// AUTO LOAD ON PAGE OPEN
// ==========================
loadRestaurants();