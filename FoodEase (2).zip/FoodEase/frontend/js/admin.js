const API = "http://localhost:5000/api";

// ======================
// ADD RESTAURANT
// ======================
function addRestaurant() {

    fetch(`${API}/restaurants/add`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            restaurant_name: document.getElementById("name").value,
            address: document.getElementById("address").value
        })
    })
    .then(res => res.json())
    .then(() => loadRestaurants());
}

// ======================
// LOAD RESTAURANTS
// ======================
function loadRestaurants() {

    fetch(`${API}/restaurants`)
    .then(res => res.json())
    .then(data => {

        let html = "";

        data.forEach(r => {
            html += `
                <div class="card p-2 mt-2">

                    <h5>${r.restaurant_name}</h5>
                    <p>${r.address}</p>

                    <button onclick="deleteRestaurant(${r.restaurant_id})">
                        Delete
                    </button>

                    <button onclick="loadMenu(${r.restaurant_id})">
                        View Menu
                    </button>

                    <div id="menu-${r.restaurant_id}"></div>

                </div>
            `;
        });

        document.getElementById("list").innerHTML = html;
    });
}

// ======================
// DELETE RESTAURANT
// ======================
function deleteRestaurant(id) {

    fetch(`${API}/restaurants/${id}`, {
        method: "DELETE"
    })
    .then(() => loadRestaurants());
}

// ======================
// LOAD MENU (ADMIN)
// ======================
function loadMenu(id) {

    fetch(`${API}/menus/${id}`)
    .then(res => res.json())
    .then(data => {

        let html = "<h6>Menu</h6>";

        data.forEach(m => {
            html += `
                <p>🍔 ${m.item_name} - Rs ${m.price}</p>
            `;
        });

        document.getElementById(`menu-${id}`).innerHTML = html;
    });
}

// INIT
loadRestaurants();