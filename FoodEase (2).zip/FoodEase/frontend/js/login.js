const API = "http://localhost:5000/api";

function login() {
    const email    = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    fetch(`${API}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    })
    .then(res => res.json())
    .then(data => {
        if (data.token) {
            // Save token and user info
            localStorage.setItem("token",   data.token);
            localStorage.setItem("user_id", data.user.user_id);
            localStorage.setItem("role",    data.user.role);
            localStorage.setItem("name",    data.user.full_name);

            // Role-based redirect
            const role = data.user.role;
            if (role === "admin")              window.location.href = "admin.html";
            else if (role === "restaurant_owner") window.location.href = "owner.html";
            else if (role === "delivery_staff")   window.location.href = "delivery.html";
            else                               window.location.href = "customer.html";

        } else {
            alert(data.message || "Login failed");
        }
    })
    .catch(err => {
        console.error(err);
        alert("Server error. Is backend running?");
    });
}