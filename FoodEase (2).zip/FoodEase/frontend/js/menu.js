const API = "http://localhost:5000/api/menu";

// LOAD MENU
function loadMenu() {
    fetch(API)
    .then(res => res.json())
    .then(data => {

        let html = "";

        data.forEach(item => {
            html += `
            <div class="col-md-4 mt-3">
                <div class="card p-3 shadow">
                    <h5>${item.food_name}</h5>
                    <p>Rs ${item.price}</p>

                    <button class="btn btn-success" onclick="addToCart(${item.menu_id})">
                        Add to Cart
                    </button>
                </div>
            </div>`;
        });

        document.getElementById("menuList").innerHTML = html;
    });
}

function addToCart(id) {
    fetch("http://localhost:5000/api/cart/add", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({
            menu_id: id,
            quantity: 1
        })
    })
    .then(res => res.json())
    .then(data => alert("Added to cart ✔️"));
}

loadMenu();