const API = "http://localhost:5000/api";

function register() {

    const full_name = document.getElementById("full_name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const phone = document.getElementById("phone").value.trim();
    const address = document.getElementById("address").value.trim();
    const role = document.getElementById("role").value;

    if (
        !full_name ||
        !email ||
        !password ||
        !phone ||
        !address ||
        !role
    ) {
        alert("Please fill all fields.");
        return;
    }

    fetch(`${API}/auth/register`, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            full_name,
            email,
            password,
            phone,
            role,
            address

        })

    })

    .then(async (res) => {

        const data = await res.json();

        if (res.ok) {

            alert(data.message);

            window.location.href = "index.html";

        } else {

            alert(data.sqlMessage || data.message);

        }

    })

    .catch(err => {

        console.log(err);

        alert("Server Error");

    });

}